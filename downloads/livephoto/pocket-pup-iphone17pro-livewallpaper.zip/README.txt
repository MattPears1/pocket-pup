Pocket Pup iPhone 17 Pro Live Wallpaper

Files:
- pocket-pup-iphone17pro-livewallpaper-black.mov: 3-second 1206x2622 dog animation on black background.
- pocket-pup-iphone17pro-keyphoto-black.jpg: matching still frame.
- pocket-pup-iphone17pro-livewallpaper-cream.mov: 3-second 1206x2622 dog animation on cream background.
- pocket-pup-iphone17pro-keyphoto-cream.jpg: matching still frame.

Most reliable iPhone-only route:
1. Send/download the .mov to the iPhone and save it to Photos.
2. Use an iPhone app such as intoLive or VideoToLive to convert the video to a Live Photo.
3. Open Photos, select the Live Photo, tap Share, then Use as Wallpaper.
4. Set it for the Lock Screen and make sure the Live Photo/motion button is enabled.

Note:
WhatsApp often treats Live Photos as normal media and may strip the still/video pairing. If that happens, use the .mov with a video-to-Live-Photo app on the iPhone.
